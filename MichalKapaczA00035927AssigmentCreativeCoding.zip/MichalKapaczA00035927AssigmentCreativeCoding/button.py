import py5
from processing.sound import SoundFile

class Button:
    def __init__(self, x, y, w, h):
        self.x = x
        self.y = y
        self.w = w
        self.h = h        
        self.pressed = False
        pass
    def render(self):
        py5.no_stroke()
        if self.pressed:
            py5.fill(0, 0, 255)
        else:
            py5.fill(0, 255, 255)
        py5.rect(self.x, self.y, self.w, self.h)
    def is_inside(self, x, y):
        return x >= self.x and x <= self.x + self.w \
        and y >= self.y and y <= self.y + self.h
    

x = 100
y = 50
w = 200
h = 50

pressed = False

b1 = Button(10, 10, 100, 60)
b1.pressed = True
b2 = Button(200, 10, 100, 60)
b2.pressed = False

buttons = [b1, b2]

sounds = []

def setup():
    global sounds
    py5.size(500, 500)
    sound_file1 = SoundFile(py5.get_current_sketch(), "666.mp3")
    sounds.append(sound_file1)
    
    sound_file2 = SoundFile(py5.get_current_sketch(), "Numb.mp3")
    sounds.append(sound_file2)

def mouse_pressed():
    global buttons, sounds

    for i in range(len(buttons)):
        button = buttons[i]
        button.pressed = button.is_inside(py5.mouse_x, py5.mouse_y)
        if button.pressed:
            sounds[i].play()

def mouse_released():
    global pressed
    print("mouse released")
    for button in buttons:
        button.pressed = False

def draw():
    global x, y, w, h, b1, b2
    py5.background(0)

    b1.render()
    b2.render()



py5.run_sketch()